
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.18.0'
version = '1.18.0'
full_version = '1.18.0'
git_revision = '2410c6d0a63cb56455fc9ab6affcf1a776c82134'
release = True

if not release:
    version = full_version
