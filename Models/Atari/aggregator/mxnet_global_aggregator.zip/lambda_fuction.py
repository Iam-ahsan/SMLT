import redis
import time
import pickle
import sys
import threading
import math
import numpy as np
import boto3
import botocore
import os
from time import sleep
ip = '3.238.3.216'
r_connect = redis.Redis(host=ip, port=6379)

def get_data(worker_id,shard_id):
   vals = r_connect.get("worker_{}_shard_{}".format(worker_id,shard_id))
  
def put_data(data, worker_id, shard_id):
    #r_connect = redis.Redis(host=ip, port=6379)
    r_connect.set("worker_{}_shard_{}".format(worker_id,shard_id),pickle.dumps(data))
    #r_connect.set("worker_{}_shard_{}".format(worker_id,shard_id),data)

    #print("downloaded shard {} for worker {}".format(shard_id, worker_id))

def parallel_upload_training_index(s3, bucket_name, filename, data):
    with open('/tmp/{}'.format(filename), 'wb') as fp:
            pickle.dump(data, fp)
    s3.Bucket(bucket_name).upload_file('/tmp/{}'.format(filename),filename)
    rm_file = '/tmp/{}'.format(filename)
    os.remove(rm_file)

def upoload_aggregated_sgd_shard(aggregator_id):
    BUCKET_NAME = 'bucket-sgd'#'s3-upload-pickle-test'
    s3_client = boto3.resource('s3')
    file_name = 'aggregated_shard_{}.pkl'.format(aggregator_id)
    s3_client.Bucket(BUCKET_NAME).upload_file('/tmp/{}'.format(file_name), file_name)

def download_sharded_sgd(aggregator_id, total_clients):
    sharded_sgd = []
    BUCKET_NAME = 's3-upload-pickle-test'
    s3_client = boto3.resource('s3')
    
    #print(os.listdir('/tmp/'))
    threads = list()
    time_download = int(time.time()*1000)
    i = 0
    #for i in range(total_clients):
    while i < total_clients:
        file_name = 'worker_{}_grads_shard_{}.pkl'.format(i,aggregator_id)
        dl_filename = 'worker_{}_grads_shard_{}.pkl'.format(i,aggregator_id)
        try:
            s3_client.Bucket(BUCKET_NAME).download_file(dl_filename, '/tmp/{}'.format(file_name))
            i +=1
            rm_file = '/tmp/{}'.format(file_name)
            os.remove(rm_file)
        except botocore.exceptions.ClientError as e:
            if e.response['Error']['Code'] == "404":
                #print("shard {} does not exist yet in S3".format(file_name))
                sleep(0.1)
                continue
                #exit(1)


def ul_agg_shard(worker_id,data):
    #r_connect = redis.Redis(host=ip, port=6379)
    #r_connect.set("aggregated_shard_{}".format(worker_id),data)
    r_connect.set("aggregated_shard_{}".format(worker_id),pickle.dumps(data))

def dl_all(total_workers):
    sharded_sgd = []
    bucket_name = 'bucket-sgd' 
    s3_client = boto3.resource('s3')
    i = 0   
    while i < total_workers:
        #r_connect.get("aggregated_shard_{}".format(i))
        file_name = 'aggregated_shard_{}.pkl'.format(i)
        try:
            s3_client.Bucket(bucket_name).download_file(file_name, '/tmp/{}'.format(file_name))
            i += 1
        except botocore.exceptions.ClientError as e:
            if e.response['Error']['Code'] == "404":
                print("Aggregated shard {} does not exist yet".format(file_name))
                #sleep(0.1)
                continue

def read_data():   
   data = ''
   '''actual_data = []
   with open("grads.pkl", "rb") as fp:
       actual_data = pickle.load(fp)
   for val in actual_data:
       print(len(val))'''
   for i in range(1024*23000):
       data = data + 'a'
   return data

def sharding_dict(mydata, keys, shards, worker_id):
    
    bucket_name = 's3-upload-pickle-test' 
    s3_client = boto3.resource('s3')
    threads = list() 
    increment = int((len(keys) /float(shards)))
    test = set()
    s = int(time.time()*1000)
    for i in range(shards):

        final_val = min(len(mydata), (i*increment) +increment)
        starting = i*increment
        data_dict = {}

        for k in range(0,len(keys)):

            if (i+k)%shards == 0:
                test.add(keys[k])
                data_dict[keys[k]] = mydata[keys[k]]

        #with open("./shards/sgd_shard_{}.pkl".format(i), 'wb') as fp:
        #    pickle.dump(data_dict, fp, protocol = -1)
        file_name = 'worker_{}_grads_shard_{}.pkl'.format(worker_id,i)
        x = threading.Thread(target=parallel_upload_training_index, args=(s3_client, bucket_name, file_name, 
            data_dict))
        threads.append(x)
        x.start()
    for thread in threads:
        thread.join()
        #r_connect.set(file_name, pickle.dumps(data_dict))
        #print("shards\t{}\tstarting\t{}\tfinal\t{}".format(len(data_dict), starting, final_val))
    e = int(time.time()*1000)
    print("Total time {}".format(e-s))

def flat_sgd():
    data = None
    with open("test_pickle", "rb") as fp:
        data = pickle.load(fp)
    flat = {}
    architecture = []
    keys = []
    print(len(data))
    for ind, val in enumerate(data):

        dimension = 0

        if len(np.shape(data[val])) > 1:
            dimension = np.shape(data[val])[1]

        if dimension > 3:
            for i in range(dimension):
                flat["{}|{}".format(val, i)] = data[val][i]
                architecture.append(dimension)
                keys.append("{}|{}".format(val,i))
        else:
            flat [val] = data[val]
            architecture.append(np.shape(data[val])[0])
            keys.append(val)
    return keys, flat

def lambda_handler(event, context):
   result = {}
   #data = ''
   #for i in range(1024*23000):
   #    data = data + 'a'
   #data = read_data()
   #increment = int(math.ceil(len(data)/float(100)))

   operation = event["operation"] 
   worker_id = event["worker_id"] 
   total_workers = event["total_workers"]
   total_shards = event["total_shards"]

   #increment = int(math.ceil(len(data)/float(total_workers)))
   if "worker" in operation:
       my_keys, flat_data= flat_sgd()
       s1 = (time.time()*1000)
       sharding_dict(flat_data, my_keys, total_shards, worker_id)
       e1 = (time.time()*1000)
       result["ul_sharded"] = e1 - s1

   if "shard_aggregator" in operation:
       
       s1 = (time.time()*1000)
       download_sharded_sgd(worker_id, total_workers)
       e1 = (time.time()*1000)

       vals = r_connect.get("worker_{}_shard_{}".format(worker_id,worker_id))
       agg_shard_data = pickle.loads(vals)
       file_name = '/tmp/aggregated_shard_{}.pkl'.format(worker_id)
       with open(file_name, 'wb') as fp:
           pickle.dump(agg_shard_data, fp)

       result["dl_sharded"] = e1 - s1
       s2 = (time.time()*1000)
       upoload_aggregated_sgd_shard(worker_id)
       e2 = (time.time()*1000)

       result["ul_agg"] = e2 - s2
      
   if "global_aggregator" in operation: 
       s1 = (time.time()*1000)
       dl_all(total_workers)
       e1 = (time.time()*1000)
       result["dl_all"] = e1 - s1
   return result
   
if __name__ == "__main__":
   print("This is main")
   event = {}
   event["operation"] = sys.argv[1]
   event["worker_id"] = 0
   event["total_workers"] = 1
   event["total_shards"] = 1
   result = lambda_handler(event, "test")
   print(result)

   '''data = ''
   for i in range(1024*23000):
       data = data + 'a'
   increment = int(math.ceil(len(data)/float(100)))
   ul_agg_shard(0,data[0:increment])'''
   #ul_sharded_pickle(data, 100, 0)
   #ul_sahrded_data(data, 1, 0)

